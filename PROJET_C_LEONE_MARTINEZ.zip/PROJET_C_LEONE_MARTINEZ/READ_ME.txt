Le main est le projet.cpp
Pour compiler, mélanger les fichier dans un seul dossier et exécuter le make file 
Les fonctions utilisés dans projet.cpp sont dans simulateur.h/c++ et ...

Pour l'instant le programme n'est pas fonctionnel niveau simulation, fin d'implantation en cours (Code débug pas encore retiré) 
